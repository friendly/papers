## Tableplot

# last modified 7/29/2008 11:51AM by MF
#  -- cosmetic changes: <- instead of = for assignment
#  -- changed library() to require()
#  -- moved extra functions to utility.R
#  -- added side.rot argument to rotate side labels
#  -- made gap.list an internal function

## TODO:
# -- table.plot() should be renamed tableplot() and made object-oriented
#    (tableplot.default) to facilitate extensions for other types of table/matrix inputs
# -- Arguments matrix.1 and matrix.2 should be renamed values and types
# -- The function should use rownames() and colnames() to set default labels
#    for a matrix argument, when these are available
# -- Arguments given default values of "yes" or "no" should use TRUE/FALSE instead
# -- The ... argument seems not to be used
# -- Should allow to automatically round or format the values printed in the cells
# -- title should either be NULL by default or use deparse(substitute(matrix.1)) to
#    print "Tableplot of X"

table.plot <- function(

	matrix.1, 		# Matrix of values; can be a matrix, or an array of 3 dimensions.
	matrix.2,		# Matrix of pattern designations (types).
	patterns = list(list(0, "black", 1, "white", "white", 0, 0.5, "grey80", "no", 1)),

	title="Tableplot", 

	side.label="row", # Or provide actual list of labels for each row.
	top.label="col",  # Or provide actual list of labels for each column.
	table.label="yes",# To have labels around the table or not.
	label.size=1,	    # Size of side/top labels.
	side.rot=0,       # Rotation for side labels

	gap=2, 		# Width of gaps in partition, if there are partitions.
	v.parts=0, 		# Column clusters; if provided, sum must equal number of columns.
	h.parts=0, 		# Row clusters; if provided, sum must equal number of rows.

	cor.matrix="no",  # For a correlation matrix.
	var.names="var",  # Or provide a list of variable names.
	
	...){

	require(grid)
	require(lattice)

  ## A function to construct a gap list.
  gap.list <- function(partitions=0,x){
  	if (length(partitions)==1) rep(0,x) else {
  	rep(1:length(partitions), partitions)-1}
  	}

	grid.newpage()

	#---Create labels for a correlation matrix, if no names provided.

	if ((cor.matrix=="yes") && (length(var.names)==1)) var.names <- paste(var.names,1:dim(matrix.1)[1])

	#---Create the pattern designation matrix when there is just one pattern.
	#---Otherwise, the pattern designation matrix is supplied by user.

	if (missing(matrix.2) || length(patterns)==1) matrix.2 <- matrix(1, dim(matrix.1)[1], dim(matrix.1)[2])

	#---Add on extra dimension to matrix.1 if matrix.1 only has two dimensions.

	if (length(dim(matrix.1))==2) {dim(matrix.1) <- c(dim(matrix.1)[1], dim(matrix.1)[2], 1)}

	#---Constructing vectors of gaps if partitions provided.

	v.gaps <- gap.list(partitions=v.parts, x=dim(matrix.1)[2])
	h.gaps <- gap.list(partitions=h.parts, x=dim(matrix.1)[1])

	#---Constructing labels, if no specific labels provided for each row/column.

	if (length(side.label)==1) side.label <- paste(side.label, 1:dim(matrix.1)[1])
	if (length(top.label)==1)  top.label  <- paste(top.label,  1:dim(matrix.1)[2]) 

	#---Create Layout 1 and write main title.

	L1 <- grid.layout(2,1,heights=unit(c(3,1),c("lines","null")))
	pushViewport(viewport(layout=L1, width=0.95, height=0.98))
	
	pushViewport(viewport(layout.pos.row=1)) 			## Push row 1 of Layout 1.
	grid.text(title, x=0.02, just=c("left", "bottom"))
	upViewport()

	#---Create Layout 2.

	L2 <- grid.layout(1,2,widths=unit(c(1,1),c("char","null")))
	pushViewport(viewport(layout.pos.row=2, layout=L2))	## Push row 2 of Layout 1.

	#---Create Layout 3.

	L3 <- grid.layout(dim(matrix.1)[1],dim(matrix.1)[2],respect=T,just=c("left","top"))
	pushViewport(viewport(layout.pos.col=2))			## Push col 2 of Layout 2;
	
	#---Push Layout 3, but with adjustments to accomodate possible partitions.

	pushViewport(viewport(layout=L3, x=0, y=1, 
				    just=c(0,1), 
				    width =unit(1,"npc")-unit(gap,"mm")*(length(v.parts)-1),
				    height=unit(1,"npc")-unit(gap,"mm")*(length(h.parts)-1)))
	
	#---Draw cellgrams.

	for (i in 1:dim(matrix.1)[1]){
		for (j in 1:dim(matrix.1)[2]){

			pushViewport(viewport(layout.pos.row=i, layout.pos.col=j))
			pushViewport(viewport(just=c(0,1), height=1, width=1, 
							x=unit(gap,"mm")*v.gaps[j], 
							y=unit(1,"npc")-unit(gap,"mm")*h.gaps[i]))					 
			
			pattern <- patterns[[matrix.2[i,j]]]

			if ((cor.matrix=="yes") && (i==j)) 

			{
			 grid.rect(gp=gpar(fill="grey90"))
			 grid.text(var.names[i],gp=gpar(cex=1.8))
			} else 

			cellgram(cell  	 = matrix.1[i,j,], 
				   shape 	 = pattern[[1]],
				   shape.col = pattern[[2]],
				   shape.lty = pattern[[3]],
				   cell.fill = pattern[[4]],
				   back.fill = pattern[[5]],
				   label	 = pattern[[6]],
				   label.size= pattern[[7]],
				   ref.col	 = pattern[[8]],
				   ref.grid	 = pattern[[9]],
				   scale.max = pattern[[10]],
				   shape.name= paste(i,j)) 
			
			##grid.rect()
			if ((j==1) && (table.label=="yes")) {
				if (side.rot==0) {grid.text(side.label[i], x=-0.04, just=1, gp=gpar(cex=label.size))}
				            else {grid.text(side.label[i], x=-0.1, just=c("center"), rot=side.rot, gp=gpar(cex=label.size))}
				}
			if ((i==1) && (table.label=="yes")) {grid.text(top.label[j],  y=1.05, vjust=0, gp=gpar(cex=label.size))}
			upViewport()
			upViewport()
			}
		}
	popViewport(0)
	}

## A function to construct a gap list.

gap.list <- function(partitions=0,x){
	if (length(partitions)==1) rep(0,x) else {
	rep(1:length(partitions), partitions)-1}
	}

