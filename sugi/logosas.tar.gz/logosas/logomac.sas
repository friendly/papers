/*-------------------------------------------------------------------*
 * LOGOMAC SAS  - Some logo application macros, using LOGO SAS       *
 *                                                                   *
 *-------------------------------------------------------------------*
 *  Author:  Michael Friendly            <FRIENDLY@YORKVM1>          *
 * Created:  9 Feb 1989 12:37:12          Copyright (c) 1989         *
 * Revised:  4 Mar 1989 18:43:05          All rights reserved        *
 * Version:  1.0                                                     *
 *                                                                   *
 *-------------------------------------------------------------------*/
 
%macro polys(sides,length);
%*--------------------------------------------;
%* Move/Draw a polygon, the Logo way          ;
%*--------------------------------------------;
    do _i_ = 1 to &sides;
       %forward(&length);
       %right(360/(&sides));
    end;
%mend  polys;
 
%macro polyspi(length,angle,decrease);
%*--------------------------------------------;
%* Draw a polyspiral, decreasing side while >0;
%*--------------------------------------------;
   _len_ = &length;
   do while (_len_ > 0);
       %forward(_len_);
       %right(&angle);
       _len_ = _len_ - &decrease;
   end;
%mend  polyspi;
 
%macro polyc(sides,length);
%*--------------------------------------------;
%* Move/Draw a centered polygon               ;
%*--------------------------------------------;
    %penup;
    %forward(&length/2);
    %pendown;
    %polys(&sides,&length);
    %penup;
    %back(&length/2);
    %pendown;
%mend  polyc;
 
%macro cpoly(sides,radius);
%*--------------------------------------------;
%* Draw a centered polygon inscribed in a     ;
%* circle of given radius.                    ;
%*--------------------------------------------;
     %* move out to circumscribed circle;
   %penup;
   %forward(&radius);
     %* turn to face along one edge of polygon;
   %right(180 - (90*(&sides-2)/&sides));
   %pendown;
     %* polygon, side as function of radius;
   %polys(&sides,(2*(&radius)*sin(&pi/&sides)));
     %* turn & move back to starting point;
   %left(180 - (90*(&sides-2)/&sides));
   %penup;
   %back(&radius);
   %pendown;
%mend cpoly;
 
%macro spingon(sides,rad,decrease,times,turn);
%*--------------------------------------------;
%* Centered polygons, of decreasing radius    ;
%*--------------------------------------------;
   _len_=&rad;
   do _j_=1 to &times;
      %cpoly(&sides,_len_);
      %right(&turn);
      _len_=_len_ - &decrease;
      end;
   %left(&turn*&times);
%mend spingon;
