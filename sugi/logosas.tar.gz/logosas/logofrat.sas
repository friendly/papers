%include goptions;             /* Local macro for device independence */
 
%include logo;                 /* get LOGO macros                     */
%include logofrac;             /* and recursive fractal macros        */
goptions hsize=5in vsize=5in;
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
%annomac;                    /* Load the annotate macros */
/*
data test1;
   %dclanno;
   %system(2,2,4);
   %frame(RED,1,1,EMPTY);
   %inilogo;
   color='BLACK';
   Do i = 1 to 4;
      %arrow(100,5);              * dont try more than depth 6! ;
      %right(90);
      end;
   %label( 0, 5,'arrow(100,5)',RED, 0,0, 1.5, duplex, 5);
proc ganno datasys anno=test1;
*/ 
data test2;
   %dclanno; %system(2,2,4);
   %inilogo;
   %right(45);
   color='BLACK';
   %repoly(4, 50, .5, 45, 3);
   %label(0,0,'repoly(4,50,.5,45,3)', RED, 0,0, 1.5, duplex, 5);
proc ganno datasys anno=test2;
%gskip;

data test3;
   %dclanno; %system(2,2,4);
   %inilogo;
   %right(30);
   color='BLACK';
   %repoly(6, 50, .5, 30, 3);
   *label(0,0,'repoly(6,50,.5,30,3)', RED, 0,0, 1.5, duplex, 5);
proc ganno datasys anno=test3;
*%gfinish;
