%include goptions;             /* Local macro for device independence */
 
%include logo;
*logo;
%include logomac;
goptions hsize=7 vsize=7;
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
 
%macro teepee(d);
   %forward(2*(&d)); %left(120);
   %forward(&d);     %left(60);
   %forward(&d);     %right(120);
   %forward(&d);     %left(60);
   %forward(&d);     %left(120);
   %forward(3*(&d)); %left(120);
   %forward(&d);
%mend teepee;
 
%macro tipgon(n,sides,size,dist,rot);
%* Draw a centered poly at distance from center;
%local s;
    %do s=1 %to &n;
       %penup; %forward(&dist); %pendown;
       %cpoly(&sides,&size);
       %penup; %back(&dist); %pendown;
       %right(360/&n);
    %end;
%mend tipgon;
 
data test1;
   xsys='2'; ysys='2';
   %inilogo;
 
   color='BLACK';
   %tipgon(10, 3, 8, 20, 0);
   color='RED';
   %tipgon(10, 3,16, 35, 0);
   color='BLUE';
   %tipgon(10, 3,24, 50, 0);
 
proc ganno datasys anno=test1;
 
*%gfinish;
