%include goptions;               /* Local macro to select device */
%include logo;       /* get basic Logo macros        */
%include logomac;    /* & Logo shape macros          */
goptions vsize=5 hsize=5;
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
 
%annomac;                    /* Load the annotate macros */
data poly1;
   drop _i_;
   %dclanno;
   %system(2,2,4);           /* use data system coordinates */
   %frame(BLACK,1,1,EMPTY);
   %inilogo;
   %move(10,10);
   %pendown;
   do i=4 to 9;
      LINE=i;
      %cpoly(i, 10);
   end;
   %label(10, 10,'Logo polys',RED,0,0, 1.5,DUPLEX,5);
*proc ganno datasys anno=poly1;
%gskip;
data poly2;
   %dclanno; %system(2,2,4);
   %frame(BLACK,1,1,EMPTY);
   %inilogo;
   do i=1 to 5;
      %penup; %home; %pendown;
      %forward(25);
      %polyspi(72,75,.5);
      %right( 72);
   end;
   %label(8,12,'POLYSPI',BLACK,0,0,1.5,DUPLEX,5);
*proc ganno datasys anno=poly2;
%gskip;
data poly3;
   %dclanno; %system(2,2,4);
   %frame(BLACK,1,1,EMPTY);
   %inilogo;
   Do I=1 to 5;
      Select(I);
         When(1) COLOR='RED';
         When(2) COLOR='GREEN';
         When(3) COLOR='BLUE';
         When(4) COLOR='BLACK';
         When(5) COLOR='PURPLE';
      End;
		COLOR='BLACK';
      %penup; %home; %pendown;
      %forward(25);
      %polyspi(72,75,.5);
      %right( 72);
   End;
   %label(12,-12,'POLYSPI',BLACK,0,0,1.5,DUPLEX,5);
proc ganno datasys anno=poly3;
%gskip;

data spin1;
   %dclanno; %system(2,2,4);
   %frame(BLACK,1,1,EMPTY);
   %inilogo;
   %spingon(6,100,4,25,4);
*proc ganno datasys anno=spin1;
%gskip;
data spin2;
   %dclanno; %system(2,2,4);
   %frame(BLACK,1,1,EMPTY);
   %inilogo;
   do H = 0, 100;
   do V = 0, 100;
      %move(H,V);
      %spingon(4, 50,2,25,4);
      end; end;
   %move(50,50);
   %spingon(4, 50,2,25,-4);
*proc ganno datasys anno=spin2;
*%gfinish;                    /* Local macro for device independence */
