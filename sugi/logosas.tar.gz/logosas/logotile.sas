%include goptions;        /* Local macro for device independence */
%include logo;            /* get LOGO macros                     */
%include logomac;
goptions hsize=7 vsize=7;
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
 
*logo;
%include tiles;
 
%macro teepee(d);
   %forward(2*(&d)); %left(120);
   %forward(&d);     %left(60);
   %forward(&d);     %right(120);
   %forward(&d);     %left(60);
   %forward(&d);     %left(120);
   %forward(3*(&d)); %left(120);
   %forward(&d);
%mend teepee;
 
%macro tpgon(size);
%local s;
    %left(30);
    %penup; %forward(&size); %pendown;
    %right(120);
    %do s=1 %to 6;
        %teepee(&size/2);
        %forward(&size);
        %right(60);
    %end;
    %left(120);
    %penup; %back(&size); %pendown;
    %right(30);
%mend tpgon;
 
%annomac;                    /* Load the annotate macros */
/*
data test1;
   %dclanno;
   xsys='2'; ysys='2';
   %inilogo;
   color='BLACK';
   %tpgon(16);
proc ganno datasys anno=test1;
*/ 
data tptile;
   %dclanno;
   xsys='2'; ysys='2';
   %inilogo;
   %let motif=%nrstr(%tpgon(16));
   /* a=16; cs=3*a; rs=cs*cos(30);  */
   %tiles(  3,3, 41.56922, 48, 24);
*proc ganno datasys anno=tptile;

%include windo;
%windo(data=tptile);
proc ganno datasys anno=tptile;
*%gfinish;
