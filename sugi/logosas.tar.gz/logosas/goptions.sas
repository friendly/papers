options nosource2;
/* Include file to control global options for all SAS/GRAPH programs */
goptions device=pscolor lfactor=3;
goptions vsize=8in;
goptions ftext=duplex;
