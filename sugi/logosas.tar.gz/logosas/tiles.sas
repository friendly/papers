/*-------------------------------------------------------------------*
 * TILES SAS  - Tesselations with an arbitrary motif                 *
 *                                                                   *
 *-------------------------------------------------------------------*
 *  Author:  Michael Friendly            <FRIENDLY@YORKVM1>          *
 * Created:  16 Jan 1990 15:32:14        Copyright (c) 1990          *
 * Revised:  29 Mar 1990 16:22:24        All rights reserved         *
 * Version:  1.0                                                     *
 *                                                                   *
 *-------------------------------------------------------------------*/
 
%macro tiles(rows,cols,rspace,cspace,offset);
%*--------------------------------------;
%* Tile a display of rows x cols images ;
%*--------------------------------------;
%local r;
   %do r = 1 %to &rows;
     xsave = x; ysave = y;
     %row( &cspace, &cols);
     %penup;
     %let offset=%eval(-1 * &offset);
     x = xsave + &offset; y=ysave;
     %right(180); %forward(&rspace);
     %left(180);
     %pendown;
   %end;
%mend tiles;
 
%global motif;
%macro row(space,n);
%*----------------------------------;
%* Paint a row of n images of motif ;
%*----------------------------------;
%local c;
   %do c = 1 %to &n;
      %unquote(&motif);
      %penup; %right(90);
      %forward(&space);
      %left(90); %pendown;
   %end;
%mend row;
