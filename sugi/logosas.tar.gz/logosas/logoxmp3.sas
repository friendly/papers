%include goptions;               /* Local macro to select device */

%include logo ;         /* Basic logo macros    */
%include logomac ;      /* & Logo shape macros  */
goptions vsize=5 hsize=5;
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
 
data poly1;
   xsys='2'; ysys='2';       /* data system */
   %inilogo;
   do i=4 to 9;
      %polys(i, 15); %right(60);
   end;
   x=9; y=30; function='LABEL '; size=2;
              text='Logo polys'; output;
proc ganno datasys anno=poly1;
