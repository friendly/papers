%include goptions;             /* Local macro for device independence */
goptions hsize=7 vsize=7;
 
*include logo;     /* get LOGO macros               */
 
%logo;                         /* autocall LOGO SAS macros      */
%include tiles            ;    /* tiles macros                  */
%include windo;                /* square up the plot window     */
 
%macro pip(size, len);
  %local i;
   %cpoly(6, &size);
   %do i = 1 %to 6;
       %arms(&size, &len, 1);
       %arms(&size, &len,-1);
       %right(60);
   %end;
%mend pip;
 
%macro arms(rad, len, dir);
   xsav =x; ysav =y;
   %penup; %forward(&len);
   %left(30*(&dir)); %pendown;
   %forward( (&rad - &len)* cos(30*atan(1)/45) );
   %right(30*(&dir)); %forward(&len);
   x=xsav ; y=ysav ;
%mend arms;
 
%annomac;                    /* Load the annotate macros */
data pip1;
   %dclanno;
   xsys='2'; ysys='2';
   *frame(RED,1,1,EMPTY);
   %inilogo;
   color='BLACK';
 
   %let motif=%nrstr(%pip(60,20));
   r=60; i=20;
       colspace = 2*(r+i) *sin(60*atan(1)/45);
       rowspace = colspace*cos(30*atan(1)/45);
       offset=round(cs/2);
   put colspace= rowspace= offset=;
   %tiles(  3,3,120, 138.56, 69);
 
 
%windo(data=pip1);
proc ganno datasys anno=pip1;
*%gfinish;
