%include goptions;               /* Local macro to select device */
%include logo ;         /* get Logo macros */
goptions vsize=5 hsize=5;
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
data example1;
   xsys='1'; ysys='1';    /* data % system */
   %inilogo;
   x = 50; y=50;
   function='MOVE    '; output;
   %pendown;
   do i=1 to 12;
      %forward(15);
      do j=1 to 5;
         %forward(20);
         %right(144);
         end;
      %back(15); %right(30);
   end;
proc ganno anno=example1;
*%gfinish;
proc print data=example1;
   id i j; var pen heading function x y;
