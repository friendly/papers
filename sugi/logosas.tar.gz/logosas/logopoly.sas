%include goptions;               /* Local macro to select device */
%include logo;       /* get basic Logo macros        */
goptions vsize=5 hsize=5;
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
 
* Pure macro version of POLYSPI;
* - decrease must be an integer;
 
%macro polyspi(length,angle,decrease);
%*--------------------------------------------;
%* Draw a polyspiral, decreasing side while >0;
%*--------------------------------------------;
   %do %while (&length > 0);
       %forward(&length);
       %right(&angle);
       %let length = %eval(&length - &decrease);
   %end;
%mend  polyspi;
 
%annomac;                    /* Load the annotate macros */
data poly2;
   %dclanno; %system(2,2,4);
   %frame(BLACK,1,1,EMPTY);
   %inilogo;
   Do I=1 to 5;
      %penup; %home; %pendown;
      %forward(25);
      %polyspi(72,75, 1);
      %right( 72);
   End;
   %label(8,12,'POLYSPI',BLACK,0,0,1.5,DUPLEX,5);
proc ganno datasys anno=poly2;
*%gfinish;                    /* Local macro for device independence */
