%include goptions;               /* Local macro to select device */
%include logo;
%include logomac;  /* & Logo shape macros  */
goptions vsize=8.51cm hsize=8.51cm horigin=0 vorigin=0;
 
%annomac;                /* annotate macros */
data poly1;
   %dclanno;
   %system(2,2,4);           /* data system */
   %inilogo;
   do i=4 to 9;
      %polys(i, 15); %right(60);
   end;
   %label(8,30,'Logo polys',RED,0,0,2.5,DUPLEX,5);
proc ganno datasys anno=poly1;
data poly1;
   %dclanno;
   %system(2,2,4);           /* data system */
   %frame(BLACK,1,1,EMPTY);
   %inilogo;
   do i=4 to 9;
      %polys(i, 15); %right(60);
   end;
   %label(8,30,'Logo polys',RED,0,0,2.5,DUPLEX,5);
run;
proc print;
%include windo;
%windo(data=poly1,out=poly1);
proc print;
proc ganno anno=poly1;
*%gfinish;
