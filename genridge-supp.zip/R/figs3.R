if (!require(genridge)) {install.packages("genridge"); library(genridge)}
library("ElemStatLearn")
library(MASS)

# Prostate data, using lpsa as response
str(prostate)
y <- prostate[, "lpsa"]
X <- data.matrix(prostate[, 1:8])

prostate1 <- prostate[,-10]  # remove train
#(lmridge <- lm.ridge(lpsa ~ ., data=prostate1, lambda=lambda))

##############################
# Fig 7b
eridge <- simple.ridge(X, y, df = 1:8)
clr <- c("black", "red", "darkgreen", "blue","darkcyan","magenta", "brown","darkgray") 
pch <- c(15:18, 7, 9, 12, 13)
matplot( eridge$df, t(eridge$beta), type="b", 
		xlim=c(1,9),
		ylim=c(-.2, .7),
    col=clr, pch=pch, cex.lab=1.5, cex=1.2,
    ylab="Coefficient", xlab="Effective degrees of freedom, df(k)" )
abline(h=0, lty=3)
laby <- eridge$beta[,8] + (1:8==3)*0.0125 -(1:8==6)*0.005 # adjust label for age, lcp
text(8, laby, rownames(eridge$beta), pos=4, cex=1.2)
text(1:8, -.2, round(eridge$lambda), cex=0.8)
text(8.1, -.2, "k", pos=4)

#dev.copy2pdf(file="prostate1.pdf")

# Fig 7a
# plot vs. lambda
matplot( eridge$lambda, t(eridge$beta), type="b", 
#		xlim=c(1,9),
		ylim=c(-.2, .7),
    col=clr, pch=pch, cex.lab=1.5, cex=1.2,
    ylab="Coefficient", xlab="Ridge constant (k)" )
abline(h=0, lty=3)

#dev.copy2pdf(file="prostate2.pdf")

# Figure 7: Alternative plots using genridge package
lambda <- rev(round(eridge$lambda)) 
pridge <- ridge(y, X, lambda=lambda)

traceplot(pridge)
traceplot(pridge, X="df")


##############################
# Figure 8
pairs.ridge(pridge, variables=colnames(pridge$coef)[1:8], radius=0.25, lwd=1, col=clr)
dev.copy2eps(file="prostate3.eps")
dev.copy2pdf(file="prostate3.pdf")

###  svd plots, done the long way

svdridge <- pridge
svdridge$coef <- svdridge$coef %*% svdridge$svd.V
rot <- function(S,L) L %*% S %*% t(L)
svdridge$cov <- lapply(svdridge$cov, rot,  t(svdridge$svd.V))

# Figure 9a
op <- par(mar=c(4, 4, 1, 1) + 0.3)
plot(svdridge, col=clr, radius=.5, 
	asp=1, ref=FALSE,
	cex.lab=1.2,
	ylim=c(-.15, 0.25),
	xlab="Dimension 1", ylab="Dimension 2")
m <- colMeans(matrix(par("usr"), 2, 2))
m <- c(.17, -0.06)
s <- .45
ty <- rep(0, 8)
ty[c(1,7,8)] <- c(+.01, 0, -.01)
arrows(m[1], m[2], m[1]+s*svdridge$svd.V[,1], m[2]+s*svdridge$svd.V[,2], angle=8, length=.15)
text(m[1]+1.05*s*svdridge$svd.V[,1], m[2]+ty+1.05*s*svdridge$svd.V[,2], rownames(svdridge$svd.V), cex=1.2)
text(svdridge$coef[c(1,3,5:8),1:2], as.character(lambda[c(1,3,5:8)]), pos=3, cex=1.2)
par(op)

#dev.copy2pdf(file="prostate4a.pdf")

# Figure 9b
# last two dimensions: collinearity
op <- par(mar=c(4, 4, 1, 1) + 0.3)
plot(svdridge, variables=7:8, col=clr, radius=.5, 
	asp=1, cex.lab=1.2, ref=FALSE,
#	ylim=c(-.15, 0.25),
	xlab="Dimension 7", ylab="Dimension 8")
m <- colMeans(matrix(par("usr"), 2, 2))
m <- c(-.12, .33)
s <- .2
arrows(m[1], m[2], m[1]+s*svdridge$svd.V[,7], m[2]+s*svdridge$svd.V[,8], angle=8, length=.15)
text(m[1]+1.05*s*svdridge$svd.V[,7], m[2]+1.05*s*svdridge$svd.V[,8], rownames(svdridge$svd.V), cex=1.2)
text(svdridge$coef[,7:8], as.character(lambda), pos=2, cex=1.25)
par(op)

#dev.copy2pdf(file="prostate4b.pdf")

# Figure 9 alternatives, using genridge package
pcaridge <- pca.ridge(pridge)
biplot(pcaridge, radius=0.5, variables=1:2, col=clr, labels=lambda, prefix="Dimension ", 
	ref=FALSE, fill=TRUE, origin=c(.17, -0.002))
biplot(pcaridge, radius=0.5, col=clr, labels=lambda, prefix="Dimension ", 
	ref=FALSE, fill=TRUE, origin=c(-.12, .33))
